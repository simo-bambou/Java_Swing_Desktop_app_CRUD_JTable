/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.accident_app;

/**
 *
 * @author Easy
 */
public class User {

private int id;
private String username,password,user_status;

public User(int id,String username,String password,String user_status){
     this.id=id;
     this.username=username;
     this.password=password;
     this.user_status=user_status;
    
}

    User(int aInt) {
    }

public int getid(){
  return id;  
}
public String getusername(){
  return username;  
}

public String getpassword(){
  return password;  
}

public String getuser_status(){
  return user_status;  
}

}
