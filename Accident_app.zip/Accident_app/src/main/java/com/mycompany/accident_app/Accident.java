/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.accident_app;

/**
 *
 * @author Simo_
 */
public class Accident {
    private int id,morts,blesses;
    private String date,pays,cite,location,cause;

    public Accident(int id, int morts, int blesses, String date, String pays, String cite, String location, String cause) {
        this.id = id;
        this.morts = morts;
        this.blesses = blesses;
        this.date = date;
        this.pays = pays;
        this.cite = cite;
        this.location = location;
        this.cause = cause;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMorts() {
        return morts;
    }

    public void setMorts(int morts) {
        this.morts = morts;
    }

    public int getBlesses() {
        return blesses;
    }

    public void setBlesses(int blesses) {
        this.blesses = blesses;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    public String getCite() {
        return cite;
    }

    public void setCite(String cite) {
        this.cite = cite;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }
    
}
